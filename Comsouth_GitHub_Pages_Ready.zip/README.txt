COMSOUTH INVENTORY — GITHUB PAGES

1. On your Samsung, create or sign in to GitHub at https://github.com
2. Create a PUBLIC repository (example: comsouth-inventory). Do not upload sensitive inventory data.
3. Upload index.html, manifest.webmanifest, sw.js and the icons folder with its two PNGs. GitHub mobile web UI may require Desktop site mode to upload files.
4. Repository Settings > Pages > Build and deployment > Deploy from a branch > main > /(root) > Save.
5. Your site URL will be https://YOUR-USERNAME.github.io/comsouth-inventory/ (replace with actual username and repo). Wait for deployment.
6. Open URL in Chrome on Samsung, menu > Add to Home screen / Install app. Grant camera permission when requested.

IMPORTANT: Your inventory is stored only in the local browser on each device, not in GitHub. Export JSON backup from the old app, then import it in this hosted version. Do not commit backups or company data to a public GitHub repository. Browser camera barcode recognition requires BarcodeDetector support and is not guaranteed on every Samsung/Chrome version. GitHub Pages does not sync inventory across devices.
